# Workshops Enrollment System

Made by 
***ZHANG Wengyu 21098431d
CHEN Derun 21098424d
YE Haowen 21098829d***

*Computational Thinking and Problem Solving (COMP1002) - Project Group 2*

User Manual:

> 1. Run `G2.py`;
> 2. enter `c` to launch the **Command Line Inteface**, 
>  or `g` to launch the **Graphic User Interface**
> 3. Existing **Administrator** user **name** and **password**:
> > admin 123456
> > admin2 123456
> > admin3 123456
> 4. Existing **Students** user **name** and **password** (allow further register):
> > cdr123 123
> > zwy456 123
> > yhw789 123